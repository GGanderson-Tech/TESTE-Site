<?php if (!defined('ABSPATH')) { exit; } ?><!doctype html>
<html class="no-js" <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip-link" href="#conteudo"><?php esc_html_e('Pular para o conteúdo', 'pinhalzinho'); ?></a>
<div class="utility"><div class="wrap utility-inner"><span>Portal oficial do Poder Legislativo</span><div class="accessibility"><a href="<?php echo esc_url(home_url('/#contato')); ?>">Atendimento ao cidadão</a><button type="button" data-font="down" aria-label="Diminuir tamanho do texto">A−</button><button type="button" data-font="up" aria-label="Aumentar tamanho do texto">A+</button><button type="button" data-contrast aria-pressed="false">Contraste</button></div></div></div>
<header class="site-header"><div class="wrap header-inner">
<div class="brand"><?php if (has_custom_logo()) { the_custom_logo(); } else { ?><a class="brand-mark" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Página inicial"><?php echo pinhalzinho_icon('building'); ?></a><?php } ?><a class="brand-text" href="<?php echo esc_url(home_url('/')); ?>"><span>CÂMARA MUNICIPAL DE</span><strong>Pinhalzinho</strong><small>ESTADO DE SÃO PAULO</small></a></div>
<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-navigation"><span class="hamburger" aria-hidden="true">☰</span> Menu</button>
<nav id="site-navigation" class="navigation" aria-label="Navegação principal"><?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => 'pinhalzinho_fallback_menu', 'depth' => 3)); ?></nav>
<details class="portal-search"><summary aria-label="Abrir busca no portal"><?php echo pinhalzinho_icon('search'); ?></summary><?php get_search_form(); ?></details>
<a class="header-cta" href="<?php echo esc_url(pinhalzinho_service_url('transparencia', 'transparência')); ?>"><?php echo pinhalzinho_icon('document'); ?> Transparência</a>
</div></header>

