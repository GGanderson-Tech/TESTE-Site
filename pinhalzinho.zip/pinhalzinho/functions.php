<?php
/** Configuração do tema Câmara Pinhalzinho. */
if (!defined('ABSPATH')) { exit; }
function pinhalzinho_setup() {
    load_theme_textdomain('pinhalzinho', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array('height' => 100, 'width' => 100, 'flex-height' => true, 'flex-width' => true));
    add_theme_support('editor-styles');
    add_editor_style('assets/editor.css');
    register_nav_menus(array('primary' => __('Navegação principal', 'pinhalzinho'), 'footer' => __('Links do rodapé', 'pinhalzinho')));
    add_image_size('pinhalzinho-card', 800, 520, true);
}
add_action('after_setup_theme', 'pinhalzinho_setup');
function pinhalzinho_assets() {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('pinhalzinho', get_stylesheet_uri(), array(), $version);
    wp_enqueue_script('pinhalzinho', get_theme_file_uri('/assets/main.js'), array(), $version, true);
    $css = ':root{--green:' . (sanitize_hex_color(get_theme_mod('pinhalzinho_green', '#022264')) ?: '#022264') . ';--gold:' . (sanitize_hex_color(get_theme_mod('pinhalzinho_gold', '#fef431')) ?: '#fef431') . ';}';
    wp_add_inline_style('pinhalzinho', $css);
}
add_action('wp_enqueue_scripts', 'pinhalzinho_assets');
function pinhalzinho_customize($customizer) {
    $customizer->add_section('pinhalzinho_institution', array('title' => __('Câmara: identidade e serviços', 'pinhalzinho'), 'priority' => 30));
    $fields = array(
        'green' => array('Cor institucional', '#022264', 'color'),
        'gold' => array('Cor de destaque', '#fef431', 'color'),
        'hero_title' => array('Título da página inicial', 'Uma Câmara mais perto de você.', 'text'),
        'hero_text' => array('Texto de apresentação', 'Acompanhe o trabalho legislativo, acesse informações públicas e participe das decisões da nossa cidade.', 'textarea'),
        'hero_image' => array('Foto principal (biblioteca de mídia)', '', 'image'),
        'transparencia_url' => array('URL do Portal da Transparência', '', 'url'),
        'ouvidoria_url' => array('URL da Ouvidoria / e-SIC', '', 'url'),
        'legislacao_url' => array('URL da legislação', '', 'url'),
        'sessoes_url' => array('URL das sessões / transmissões', '', 'url'),
        'vereadores_url' => array('URL da página de vereadores', '', 'url'),
        'address' => array('Endereço oficial', '', 'textarea'),
        'phone' => array('Telefone oficial', '', 'text'),
        'email' => array('E-mail oficial', '', 'email'),
        'hours' => array('Horário de atendimento', '', 'text'),
    );
    foreach ($fields as $key => $field) {
        list($label, $default, $type) = $field;
        $name = 'pinhalzinho_' . $key;
        $sanitize = $type === 'color' ? 'sanitize_hex_color' : ($type === 'url' || $type === 'image' ? 'esc_url_raw' : ($type === 'email' ? 'sanitize_email' : ($type === 'textarea' ? 'sanitize_textarea_field' : 'sanitize_text_field')));
        $customizer->add_setting($name, array('default' => $default, 'sanitize_callback' => $sanitize));
        $args = array('label' => $label, 'section' => 'pinhalzinho_institution', 'type' => $type);
        if ($type === 'color') { $customizer->add_control(new WP_Customize_Color_Control($customizer, $name, $args)); }
        elseif ($type === 'image') { $customizer->add_control(new WP_Customize_Image_Control($customizer, $name, $args)); }
        else { $customizer->add_control($name, $args); }
    }
}
add_action('customize_register', 'pinhalzinho_customize');
/** Ícones locais: nenhuma fonte ou serviço externo. */
function pinhalzinho_icon($name) {
    $paths = array(
        'arrow' => '<path d="M5 12h14m-6-6 6 6-6 6"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/>',
        'building' => '<path d="m3 8 9-5 9 5M4 21h16M3 9h18M6 10v8m6-8v8m6-8v8"/>',
        'document' => '<path d="M14 3H5v18h14V8l-5-5Zm0 0v5h5M8 12h8m-8 4h6"/>',
        'chat' => '<path d="M21 11a8 8 0 0 1-8 8H7l-4 3V11a9 9 0 0 1 18 0Z"/><path d="M8 10h8m-8 4h5"/>',
        'play' => '<rect x="2" y="5" width="20" height="14" rx="4"/><path d="m10 9 5 3-5 3Z"/>',
        'people' => '<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m1-17a3 3 0 0 1 0 6m2 4a5 5 0 0 1 3 5v2"/>',
        'calendar' => '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18m-13 4h2m4 0h2"/>',
        'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    );
    return '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($paths[$name] ?? $paths['arrow']) . '</svg>';
}
function pinhalzinho_service_url($key, $term) {
    $url = get_theme_mod('pinhalzinho_' . $key . '_url');
    return $url ? $url : add_query_arg('s', $term, home_url('/'));
}
function pinhalzinho_category_url($slug) {
    $category = get_category_by_slug($slug);
    return $category ? get_category_link($category->term_id) : add_query_arg('s', str_replace('-', ' ', $slug), home_url('/'));
}
function pinhalzinho_fallback_menu() {
    echo '<ul class="menu">';
    $items = array('Início' => home_url('/'), 'Notícias' => home_url('/#noticias'), 'Documentos' => home_url('/#documentos'), 'Atividade Legislativa' => home_url('/?post_type=ph_propositura'), 'Vereadores' => home_url('/?post_type=ph_vereador'), 'Contato' => home_url('/#contato'));
    foreach ($items as $label => $url) { echo '<li><a href="' . esc_url($url) . '">' . esc_html($label) . '</a></li>'; }
    echo '</ul>';
}
function pinhalzinho_empty($text) { echo '<p class="empty-state">' . esc_html($text) . '</p>'; }


function pinhalzinho_record_types($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_search()) {
        $query->set('post_type', array('post','page','ph_documento','ph_vereador','ph_sessao','ph_licitacao','ph_propositura'));
    }
}
add_action('pre_get_posts', 'pinhalzinho_record_types');

function pinhalzinho_portrait($size='medium') {
    $angle=(int)get_post_meta(get_the_ID(),'_ph_portrait_angle',true);
    $angle=in_array($angle,array(90,270),true) ? $angle : 0;
    echo '<span class="portrait-frame portrait-angle-'.esc_attr($angle).'">';
    the_post_thumbnail($size,array('loading'=>'lazy','alt'=>get_the_title()));
    echo '</span>';
}
