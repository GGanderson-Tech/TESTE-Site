(() => {
  'use strict';
  document.documentElement.classList.remove('no-js');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.navigation');
  if (toggle && nav) {
    const close = () => { toggle.setAttribute('aria-expanded', 'false'); nav.classList.remove('is-open'); };
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open);
    });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && nav.classList.contains('is-open')) { close(); toggle.focus(); } });
    nav.addEventListener('click', event => { if (event.target.closest('a')) close(); });
    window.matchMedia('(min-width: 1101px)').addEventListener('change', event => { if (event.matches) close(); });
  }
  const read = key => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (key, value) => { try { localStorage.setItem(key, value); } catch { /* Preferência apenas nesta sessão. */ } };
  let scale = Number(read('pinhalzinho-font')) || 100;
  const setFont = () => { scale = Math.max(100, Math.min(130, scale)); document.documentElement.style.fontSize = `${scale}%`; };
  setFont();
  document.querySelectorAll('[data-font]').forEach(button => button.addEventListener('click', () => { scale += button.dataset.font === 'up' ? 10 : -10; setFont(); save('pinhalzinho-font', String(scale)); }));
  const contrast = document.querySelector('[data-contrast]');
  if (contrast) {
    const setContrast = enabled => { document.body.classList.toggle('high-contrast', enabled); contrast.setAttribute('aria-pressed', String(enabled)); };
    setContrast(read('pinhalzinho-contrast') === 'true');
    contrast.addEventListener('click', () => { const enabled = !document.body.classList.contains('high-contrast'); setContrast(enabled); save('pinhalzinho-contrast', String(enabled)); });
  }
})();

