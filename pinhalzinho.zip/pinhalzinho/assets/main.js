(() => {
  'use strict';
  document.documentElement.classList.remove('no-js');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.navigation');
  if (toggle && nav) {
    const close = () => { toggle.setAttribute('aria-expanded', 'false'); nav.classList.remove('is-open'); };
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open)); nav.classList.toggle('is-open', open);
    });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && nav.classList.contains('is-open')) { close(); toggle.focus(); } });
    nav.addEventListener('click', event => { if (event.target.closest('a')) close(); });
    window.matchMedia('(min-width: 1101px)').addEventListener('change', event => { if (event.matches) close(); });
  }
  const read = key => { try { return localStorage.getItem(key); } catch { return null; } };
  const save = (key, value) => { try { localStorage.setItem(key, value); } catch { /* Preferência apenas nesta sessão. */ } };
  let scale = Number(read('pinhalzinho-font')) || 100;
  const setFont = () => { scale = Math.max(100, Math.min(130, scale)); document.documentElement.style.fontSize = `${scale}%`; };
  setFont();
  document.querySelectorAll('[data-font]').forEach(button => button.addEventListener('click', () => { scale += button.dataset.font === 'up' ? 10 : -10; setFont(); save('pinhalzinho-font', String(scale)); }));
  const contrast = document.querySelector('[data-contrast]');
  if (contrast) {
    const setContrast = enabled => { document.body.classList.toggle('high-contrast', enabled); contrast.setAttribute('aria-pressed', String(enabled)); };
    setContrast(read('pinhalzinho-contrast') === 'true');
    contrast.addEventListener('click', () => { const enabled = !document.body.classList.contains('high-contrast'); setContrast(enabled); save('pinhalzinho-contrast', String(enabled)); });
  }
})();

// Submenus operáveis por toque, mouse e teclado, com apenas dois níveis visuais.
(() => {
 const nav=document.querySelector('.navigation'); if(!nav)return;
 nav.setAttribute('data-enhanced','true');
 nav.querySelectorAll('li').forEach((item,index)=>{
  const submenu=Array.from(item.children).find(el=>el.classList.contains('sub-menu'));
  if(!submenu)return;
  const label=item.querySelector('a')?.textContent.trim()||'menu';
  submenu.id=`submenu-${index}`;
  const button=document.createElement('button');button.type='button';button.className='submenu-toggle';button.textContent='⌄';button.setAttribute('aria-label',`Abrir submenu: ${label}`);button.setAttribute('aria-controls',submenu.id);button.setAttribute('aria-expanded','false');item.insertBefore(button,submenu);
  button.addEventListener('click',()=>{const open=button.getAttribute('aria-expanded')!=='true';button.setAttribute('aria-expanded',String(open));item.classList.toggle('submenu-open',open);});
 });
 nav.addEventListener('keydown',e=>{if(e.key==='Escape'){nav.querySelectorAll('.submenu-open').forEach(li=>{li.classList.remove('submenu-open');li.querySelector('.submenu-toggle')?.setAttribute('aria-expanded','false');});}});
 document.addEventListener('click',e=>{if(!nav.contains(e.target)){nav.querySelectorAll('.submenu-open').forEach(li=>{li.classList.remove('submenu-open');li.querySelector('.submenu-toggle')?.setAttribute('aria-expanded','false');});}});
})();
